({
  size: 'size',
  maxFileSize: 'size',
  avoid: { array: 'string', required: false },
});
