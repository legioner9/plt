({
  keepDays: 100,
  writeInterval: 3000,
  writeBuffer: 64 * 1024,
  toStdout: ['error', 'warn', 'info', 'debug', 'log'],
  toFile: ['error', 'warn', 'info', 'debug', 'log'],
});
