({
  size: {
    js: 'string',
    kind: 'scalar',
    rules: ['length'],
    symbols: '1234567890kmgtpezyb. ',
  },
});
