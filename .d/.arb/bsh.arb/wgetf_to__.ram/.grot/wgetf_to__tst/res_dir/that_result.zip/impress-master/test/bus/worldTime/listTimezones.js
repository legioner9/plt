({
  parameters: {
    area: 'string',
  },

  method: {
    get: 'timezone',
    path: ['area'],
  },

  returns: { array: 'string' },
});
