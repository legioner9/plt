#!/bin/bash

# Wraps the 'sed' swap command.

sed -i "s/$1/$2/g" $3
