#!/bin/bash

function hi {
    echo "hello there"
}

"$@"
