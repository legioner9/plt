#!/bin/bash

# Runs OSX software update

echo 'Mac Updates'
softwareupdate -l
echo
