
## Usage

    rvm gemset copy ruby-from[@gemset] ruby-to[@gemset]


## Description

Copy the `ruby-from` `gemset`s gems (`default` if omitted) to the `ruby-to` `gemset`.
