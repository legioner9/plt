#!/bin/bash

{editor_start_command} {dir_project}