#!/bin/bash

${_wrp2_} cd --_xxd ${dir_fns_}/dir_${name_fn_}/_${name_fn_}/_debug

${_cr_sh_} mdeb.sh

${_upg_path_} mdeb.sh