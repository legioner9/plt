#!/bin/bash

. {path_patch}