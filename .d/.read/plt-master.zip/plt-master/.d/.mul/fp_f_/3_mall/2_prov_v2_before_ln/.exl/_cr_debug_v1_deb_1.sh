#!/bin/bash

${_wrp2_} cd --_xxd ${dir_fns_}/dir_${name_fn_}/_${name_fn_}/_debug/v1

${_cr_sh_} deb_1.sh

${_upg_path_} deb_1.sh