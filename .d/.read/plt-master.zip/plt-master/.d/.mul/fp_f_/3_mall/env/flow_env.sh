#!/bin/bash 

tml_dir=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.tml

insert_dir=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.insert

exl_dir=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.exl

exl_file=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.exl/main.exl

main_sh=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.exl/main.sh


