#!/bin/bash

${_wrp2_} cp -rf --_xxd ${PLT_PATH}/.d/.fs_standarts.ax/.dd --_xxd ${dir_fns_}/dir_${name_fn_}/.d

${_wrp2_} cd --_xxd ${dir_fns_}/dir_${name_fn_}/.d

echo ${_wrp2_} rm --_xxf ${dir_fns_}/dir_${name_fn_}/.d/.dd/cr_tree_gign_dir.sh

${_wrp2_} rm --_xxf ${dir_fns_}/dir_${name_fn_}/.d/.dd/cr_tree_gign_dir.sh

echo ${_cr_sh_} ${dir_fns_}/dir_${name_fn_}/.d/.dd/cr_tree_gign_dir.sh
${_cr_sh_} ${dir_fns_}/dir_${name_fn_}/.d/.dd/cr_tree_gign_dir.sh

#? ins

this_file=${dir_fns_}/dir_${name_fn_}/.d/.dd/cr_tree_gign_dir.sh

${_is_est_} ${this_file} -f

${_cr_f_dir_insert_} --name ${this_file} --dir_insert ${insert_dir}/cr_dotd_dotdd
