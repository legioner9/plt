#!/bin/bash

_name_dir="${PWD}/dir_${name_fn_}"
_dotd_dir="${_name_dir}/.d.ax"
_dotd_dir_sal="${_dotd_dir}/.sal.ax"

# tml_dir=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.tml

# insert_dir=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.insert

# exl_dir=${PLT_PATH}/.d/.mul/fp_f_/${grad_}/${tail_}/.exl

# cntl_args=(" _h  _man _tst _puml _flw _extst _deb _mdeb _lst _go _extst1 _extst2 _extst3 _extst4  _exdeb1 _exdeb2 _exdeb3 _exdeb4 ")