#!/bin/bash
#! _${name_fn_}/_mdeb -> .d/.mdeb

# ${_wrp2_} cp -rf ${PATH_FS_STANDARTS_FX_DIR}/_mdeb ${dir_fns_}/dir_${name_fn_}/_${name_fn_}
${_wrp2_} cp -rf ${PATH_FS_STANDARTS_FX_DIR}/.mdeb ${dir_fns_}/dir_${name_fn_}/.d

# mdeb_mdeb_dir=${dir_fns_}/dir_${name_fn_}/_${name_fn_}/_mdeb
# mdeb_cntl_dir=${dir_fns_}/dir_${name_fn_}/_${name_fn_}/_mdeb/.cntl
# cr_mdeb_insert=${PATH_MUL_DIR}/fp_f_/${grad_}/${tail_}/.insert/cr_mdeb
mdeb_mdeb_dir=${dir_fns_}/dir_${name_fn_}/.d/.mdeb
mdeb_cntl_dir=${dir_fns_}/dir_${name_fn_}/.d/.mdeb/.cntl
cr_mdeb_insert=${PATH_MUL_DIR}/fp_f_/${grad_}/${tail_}/.insert/cr_mdeb

cd ${mdeb_cntl_dir}

#? ${_cr_sh_} _cr_${name_fn_}mdeb_postfix.sh
#? cr_sh_ -> cr_f_

name_file_sh="_cr_${name_fn_}mdeb_postfix.sh"

# ${_cr_sh_} ${name_file_sh}
# ${_cr_f_dir_insert_} --name ${name_file_sh} --dir_insert ${cr_mdeb_insert}/cr_fn_mdeb_postfix

${_cr_f_} ${name_file_sh} --tml ${PLT_PATH}/.d/.fs_standarts.ax/init_body.sh

${_cr_f_dir_insert_} --name ${name_file_sh} --dir_insert ${PLT_PATH}/.d/.mul/fp_f_/3_mall/2_prov/.insert/cr_mdeb/_cr_fn_mdeb_postfix/init_body
${_cr_f_dir_insert_} --name ${name_file_sh} --dir_insert ${PLT_PATH}/.d/.mul/fp_f_/3_mall/2_prov/.insert/cr_mdeb/_cr_fn_mdeb_postfix/next_step_1

${_cr_f_} ${name_file_sh} --vi0 ${name_fn_} --vr0 {name_fn_}
${_cr_f_} ${name_file_sh} --vi0 ${mdeb_cntl_dir} --vr0 {mdeb_cntl_dir}
${_obs_quis_} ${name_file_sh}

#? ${_cr_sh_} _start_${name_fn_}mdeb.sh
#? cr_sh_ -> cr_f_

name_file_sh="_start_${name_fn_}mdeb.sh"

${_cr_f_} ${name_file_sh} --tml ${PLT_PATH}/.d/.fs_standarts.ax/init_body.sh

${_cr_f_dir_insert_} --name ${name_file_sh} --dir_insert ${PLT_PATH}/.d/.mul/fp_f_/3_mall/2_prov/.insert/cr_mdeb/_start_fn_mdeb/init_body
${_cr_f_dir_insert_} --name ${name_file_sh} --dir_insert ${PLT_PATH}/.d/.mul/fp_f_/3_mall/2_prov/.insert/cr_mdeb/_start_fn_mdeb/next_step_1

${_cr_f_} ${name_file_sh} --vi0 ${name_fn_} --vr0 {name_fn_}
${_cr_f_} ${name_file_sh} --vi0 ${mdeb_cntl_dir} --vr0 {mdeb_cntl_dir}
${_obs_quis_} ${name_file_sh}

${_cr_shfn_} ${name_fn_}mdeb.sh
${_cr_f_dir_insert_} --name ${name_fn_}mdeb.sh --dir_insert ${cr_mdeb_insert}/fn_mdeb
${_obs_quis_} ${name_fn_}mdeb.sh
${_cr_f_dir_insert_} --name ${name_fn_}mdeb.sh --dir_insert ${cr_mdeb_insert}/fn_mdeb_zzz20

${_wrp2_} . _cr_${name_fn_}mdeb_postfix.sh 1 "zx"

${_cr_f_dir_insert_} --name ${mdeb_mdeb_dir}/a1_fp_f_mdeb_zx.sh --dir_insert ${cr_mdeb_insert}/fn_mdeb_zx
# read -p "read 1"
# ${_wrp2_} . ${mdeb_cntl_dir}/_start_${name_fn_}mdeb.sh 1
# read -p "read 2"

#? ${PATH_MUL_DIR}/fp_f_/${grad_}/${tail_}/.insert/cr_mdeb
