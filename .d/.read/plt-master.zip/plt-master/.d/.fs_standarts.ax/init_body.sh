#!/bin/bash

#{init_body}