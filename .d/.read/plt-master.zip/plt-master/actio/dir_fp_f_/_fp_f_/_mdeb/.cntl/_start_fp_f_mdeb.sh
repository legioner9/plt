#!/bin/bash

. /home/st/REPOBARE/_repo/plt/actio/dir_fp_f_/_fp_f_/_mdeb/.cntl/fp_f_mdeb.sh

fp_f_mdeb "$1"