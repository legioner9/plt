#!/usr/bin/env bash

cd $PLT_PATH
git config core.hooksPath .githooks