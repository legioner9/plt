$\mathscr{Plt\ erit\ crescere\ a\ fons}$

## [standarts plt](.d/.man/standarts)

[man files](.d/.man/standarts/fn_man_files/tml.man)

## [discriptions](.d/.lego)
    
[about_structure_repo](.d/.lego/about_structure_this_repo.man)

[recommendation](.d/.lego/2_recommendation.man)

# P.S.

- .s/Debag/git_short.sh - start short git plt
- in .d/.mul/fp_f_/2/.insert/_fn_fff_sh/2: add fn_to_mdeb.sh file at _{FNN}/_mdeb and auto add to {FNN}_mdeb fumction menu
- fp_f_mdeb_ 2 fiches future and FNAA      
- _head must be able in any fn
- use ${_is_est} as simple checking args without start exec string

# bags 

- ${_wrp2_} file --_xxd1 ~/ not started (--_xxd1 is false arg)
- ${_wrp2_} not correct with string contane '>'
- ${_wrp2_} change env in args

# raports



# update fp_f

scae_relevance__possibility_of_using: veri prov absc
scae_complexity_stucture_syll__ease_of_use: prim secu mall raqu ague

 fs_compare, exec_compare
 
- "unset" garg variable not need, ther allready local, but tst remove this fich

# plans

## teach upg_path_ use .env 

## use global nid_nid, nid_body to inject to .d/.cir/p1.cir

## do fn

- teach cr_sh_ and cr_shfn_ salent mode and do fp_f_mall_prov_1_extst/extst_1/ex5 res ONLY "that from zx"

## plan dirs in /home/st/REPOBARE/_repo/plt/.d/.mul/fp_f_
- nnn2_ like fp_f_ in /secundo (uxix+/primus) or /mall flow 1
- lll2_ like lib/user (uxix) in /primus flow 5
- jjj2_ like lib/user (user mini simple utils) in /mall2 flow 7
- flow 2 - for fiches
- flow 3 - for update before copy to flow 1
- flow 4 - for update before copy to flow 5
- flow 6 - for update before copy to flow 7

# plans B

- nginx, sites, mediawiki ...
- caelum progect - wiki in repo (pars .dd dirs)
- do fn: install from tsf - codium {before delit file .vscode-oss dir not created}, intellij ...
- in mm_... include point start flow AND correct list .exl and other

## any

- in .insert files to escape control characters
- in .md files '<>' red selection
- in .dd/textus.man main explanations

# see
- Scribus как Корел
- Посмотрите GIMP и Inkscape
- 
