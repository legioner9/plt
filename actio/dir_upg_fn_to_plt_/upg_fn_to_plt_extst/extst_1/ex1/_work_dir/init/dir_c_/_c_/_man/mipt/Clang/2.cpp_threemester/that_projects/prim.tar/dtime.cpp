#include "timedat.h"

DataTime::DataTime(){
	ctm = 0;
	nanos = 0;
	bzero(&tmdat,sizeof(struct tm));
};

DataTime::DataTime(const char* s){
	int y,mon,day,h,min,sec;
	sscanf(s,"%d-%d-%d %d:%d:%d.%d",&y,&mon,&day,&h,&min,&sec,&nanos);
	tmdat.tm_year = y - 1900;
	tmdat.tm_mon = mon - 1;
	tmdat.tm_mday = day;
	tmdat.tm_hour = h + 3;
	tmdat.tm_min = min;
	tmdat.tm_sec = sec;
	ctm = mktime(&tmdat);
	
};
void CTime::getTime(time_t a, int nn){
	ctm = a;
	nanos = nn;
};
CTime DataTime::operator-(const DataTime& a){
	CTime tmp;
	time_t sec = ctm - a.ctm - 1;
	int nn = 1000 + nanos - a.nanos;
	tmp.getTime(sec + nn / 1000, nn % 1000);
	return tmp;
};

void DataTime::print(){
  struct tm tmp;
	char buffer[100];
	tmp = *localtime(&ctm);
	strftime (buffer,80,"%y-%m-%d %X",&tmp);
	printf("%s.%d\n",buffer,nanos);
};
