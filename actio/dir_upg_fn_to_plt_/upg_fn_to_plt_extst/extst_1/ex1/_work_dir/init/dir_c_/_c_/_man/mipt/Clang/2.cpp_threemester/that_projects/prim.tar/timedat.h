#include <iostream>
#include <cstdlib>
#include <fstream>
#include <ctime>
#include <sstream>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#define TLimit 315360000
using namespace std;

class CTime{
time_t ctm;
int  nanos;
public:
	CTime();
	CTime( const CTime&);
	void getTime(const char*);
	void getTime(time_t,int);
	int operator==(const CTime&);

        int operator>(CTime);
        int operator>=(CTime);
        int operator<(CTime);
        int operator<=(CTime);

	CTime operator+(const CTime&);

	CTime operator-(const CTime&);
	void print();        
	ostream& put(ostream&);
};


class DataTime{
  struct tm tmdat;
  time_t ctm;
  int  nanos;
public: 
	DataTime();
	DataTime(const char*);
	void getData(char*);
	int operator==(const DataTime&);
	DataTime operator+(const CTime&);
	CTime operator-(const DataTime&);
  void print();        
	ostream& put(ostream&);
};
