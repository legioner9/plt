#include "timedat.h"

int main(int argc, char** argv){
  char ss[100];//="13 7:25:10.9876";
	FILE *fin;	
	if(argc > 1){
		fin = fopen(argv[1],"r");
		if( errno ){	
			perror("file open: ");
			exit(1);
		}
	}
	fgets(ss,99,fin);
	DataTime dt(ss);
	dt.print();
	fgets(ss,99,fin);
	DataTime dt1(ss);
	dt1.print();
	CTime res;
	res = dt - dt1;
	res.print();

 return 0;
}
