#include "timedat.h"

CTime::CTime(){
  ctm = 0;
	nanos = 0;
};

CTime::CTime(const CTime& a){
	ctm = a.ctm;
	nanos = a.nanos;
};

void CTime::getTime(const char* s){
	int day,h,min,sec;
	sscanf(s,"%d%d:%d:%d.%d",&day,&h,&min,&sec,&nanos);
	ctm = (((day * 24) + h) * 60 + min) * 60 + sec;
};

void CTime::print(){
	int day = ctm / 86400;
  int h = (ctm / 3600) % 24;
	int min  = (ctm /60) % 60;
  int sec = ctm % 60;
   printf("%d %d:%d:%d.%d ", day, h, min, sec, nanos);
};

CTime CTime::operator+(const CTime& a){
		CTime tmp;
		tmp.nanos = (nanos + a.nanos) % 1000;
		tmp.ctm = ctm + a.ctm + (nanos + a.nanos) / 1000;
		return tmp;
};
